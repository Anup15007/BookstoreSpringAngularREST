"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var bookstore_app_module_1 = require('./bookstore-app.module');
var platform = platform_browser_dynamic_1.platformBrowserDynamic();
platform.bootstrapModule(bookstore_app_module_1.BookStoreAppModule);
//# sourceMappingURL=main.js.map