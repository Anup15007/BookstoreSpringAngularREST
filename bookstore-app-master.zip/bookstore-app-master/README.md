# bookstore-app
a bookstore app with angular 2 and bootstrap

Plunker link is: https://embed.plnkr.co/9PcPcVHl8mimugjkHWUu/


To run the app on local machine, node.js is required to be installed on the machine.

Copy all the files into a local folder.( ex. bookstore-app)

Navigate to 'bookstore-app' folder. 

Install node dependencies using the command

npm install

Install jquery and bootstrap dependencies using the below commands:

npm install jquery

npm install bootstrap


Now run the below command to create a lite server 

npm start

An instance of lite server will be running and watching the changes in the typescript file.
This will also open a tab in the browser for the application.
